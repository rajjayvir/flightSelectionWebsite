const FlightInfo = [
	{
		code: "CF0000",
		destination: "Toronto",
		airline: "AirCanada",
		stops: 0,
		time: 90,
		airport: "YHZ",
		departTime: "10:05",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod."
	},
	{
		code: "CF0001",
		destination: "Montreal",
		airline: "Westjet",
		stops: 0,
		time: 50,
		airport: "YHZ",
		departTime: "10:05",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod ."
	},
	{
		code: "CF1234",
		destination: "Vancouver",
		airline: "AirCanada",
		stops: 0,
		time: 50,
		airport: "YHZ",
		departTime: "11:35",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod."
	},
	{
		code: "CF1111",
		destination: "Paris",
		airline: "Westjet",
		stops: 2,
		time: 20,
		airport: "YYZ",
		departTime: "18:25",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod."
	},
	{
		code: "CF0021",
		destination: "Cancun",
		airline: "United",
		stops: 1,
		time: 99,
		airport: "YHZ",
		departTime: "13:05",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod."
	},
	{
		code: "CF0022",
		destination: "New York",
		airline: "Westjet",
		stops: 2,
		time: 45,
		airport: "YYZ",
		departTime: "14:25",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod."
	},
	{
		code: "CF2023",
		destination: "Los Angeles",
		airline: "Air Canada",
		stops: 3,
		time: 40,
		airport: "YYZ",
		departTime: "11:25",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod."
	},
	{
		code: "CF2100",
		destination: "Tokyo",
		airline: "United",
		stops: 2,
		time: 85,
		airport: "YYZ",
		departTime: "15:25",
		info: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod."
	}
]
