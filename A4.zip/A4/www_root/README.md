<!--- The following README.md sample file was adapted from https://gist.github.com/PurpleBooth/109311bb0361f32d87a2#file-readme-template-md by Raghav Sampangi for academic use --->  

# Assignment 4 (A4) in CSCI 1170 (Fall 2022)

Date Created: 29 NOV 2022
Last Modification Date: 01 DEC 2022

## Author(s)

- Full Name: Jayvirsinh Raj
- Email: jayvir@dal.ca

## Citations/Attributions

1. Used Content from Brightspace, CSCI 1170 page assignment
2. Used links from the https://www.google.com/flights/

# Summary
In this assignment, I have used concepts of CSS and javascript to design a flight selection webpage. Where a user can
 add fight information to a cart(flight selection bag) . 